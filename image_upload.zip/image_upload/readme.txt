Image upload

From UI upload image
store it in mysql as blob image type
Upload image on single click
drag and drop image to upload
make ajax call to upload.php to upload php and store in mysql blob
Support multiple upload image on click and on drag and drop both
on hover show delete icon to delete image from UI and mysql too
for delete also make ajax call to delete.php
image gallary is responsive
images are also responsive on all screen size

